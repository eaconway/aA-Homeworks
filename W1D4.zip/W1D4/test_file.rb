def hi
  puts "hi"
end

puts "hey!"
