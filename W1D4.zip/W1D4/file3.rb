puts "whats good"
